from setuptools import setup, find_packages

setup(name="client_chat_Auuu",
      version="0.1.0",
      description="client_chat_Auuu",
      author="Levon S",
      author_email="levons@yandexx.ru",
      packages=find_packages(),
      install_requires=['PyQt5', 'sqlalchemy', 'pycryptodome', 'pycryptodomex']
      )
